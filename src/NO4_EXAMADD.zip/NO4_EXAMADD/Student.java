package NO4_EXAMADD;

public abstract class Student {
  public abstract void getMessage(long id,String name);
  public abstract void putMesaage();
}
