package NO4_EXAMADD;

public  class StuInFoReader {
    Student stu;
    StuInFoReader(Student stu){
       this.stu=stu;
    }
  public void putMassage(){
      stu.putMesaage();
  }
}
