package NO4_EXAMADD2;

public interface Student {//接口
    public void getMassage(long id,String name);
    public void putMassage();
}
